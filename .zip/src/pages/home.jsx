import { FaLocationDot } from "react-icons/fa6";

function Home() {
  return (
    <>
      <div className="flex flex-col sm:flex-row gap-4 p-4">

        {/* LEFT SIDE */}
        <div className="flex flex-col gap-4 w-full sm:w-2/3 ">

          <div className="bg-white/10 backdrop-blur-xl border border-white/20 sm:p-15 p-5 md:p-10 rounded-2xl text-gray-100 h-75 flex justify-between items-center">
             
            <div className="flex-1">
                <div className="flex items-center gap-2 text-lg font-semibold">
                <FaLocationDot />
                <span>Coimbatore</span>
                </div>

                <p className="text-sm opacity-70 mt-1">8:15 AM</p>

                <div className="flex items-center gap-3 mt-4">
                <h1 className="text-5xl font-bold">26°C</h1>
                <p className="text-sm opacity-80">Partly Sunny · Feels like 28°C</p>
                </div>

                <p className="mt-3 text-md sm:text-md opacity-80 leading-relaxed">
                Light winds and warm morning. Slight chance of rain in the evening.
                <br />Humidity remains high with clear skies expected into Tuesday.
                </p>
            </div>

            <div className="flex-shrink-0 ml-6">
                <img 
                src="src/assets/cloud.png" 
                alt="Weather" 
                className="w-20 sm:w-28 md:w-72 opacity-90"
                />
            </div>

            </div>


          {/* Forecast */}
          <div className="bg-white/10 backdrop-blur-xl border border-white/20 p-5 rounded-2xl text-gray-100">

            <div className="flex justify-center bg-white/5 rounded-full py-1 px-1 sm:px-3 w-fit mx-auto">
              <button className="px-4 py-1 text-sm rounded-full bg-white/30">Today</button>
              <button className="px-4 py-1 text-sm text-gray-300 hover:text-white transition">Week</button>
              <button className="px-4 py-1 text-sm text-gray-300 hover:text-white transition">Month</button>
            </div>

            <div className="grid grid-cols-4 gap-1 sm:gap-3 mt-6 h-25">
              {[
                { time: "9:00", icon: "☀️", temp: "26°C" },
                { time: "10:00", icon: "🌤️", temp: "27°C" },
                { time: "11:00", icon: "⛅", temp: "28°C" },
                { time: "12:00", icon: "🌥️", temp: "29°C" },
              ].map((item, i) => (
                <div key={i} className="bg-white/10 backdrop-blur-md p-3 rounded-xl text-center">
                  <p className="text-xs opacity-70">{item.time}</p>
                  <p className="text-xl">{item.icon}</p>
                  <p className="text-xs opacity-70">{item.temp}</p>
                </div>
              ))}
            </div>
          </div>

        </div>

        {/* RIGHT SIDE */}
        <div className=" pt-1 px-10 pb-1 rounded-2xl text-gray-100 w-full sm:w-1/3">
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-semibold mb-3">Other Cities</h2>
          <h2 className="text-sm opacity-70 hover:opacity-100 hover:underline transition">see less</h2>
        </div>
          {[
            { country: "China", city: "Beijing", weather: "Cloudy" },
            { country: "Japan", city: "Tokyo", weather: "Sunny" },
            { country: "Brazil", city: "Brasilia", weather: "Rain" },
            { country: "Germany", city: "Berlin", weather: "Snow" },
            { country: "Australia", city: "Canberra", weather: "Windy" },
          ].map((c, i) => (
            <div key={i} className="bg-white/10 backdrop-blur-md p-3 rounded-xl mb-3">
              <p className="text-xs opacity-60">{c.country}</p>
              <p className="text-lg font-medium">{c.city}</p>
              <p className="text-xs opacity-60">{c.weather}</p>
            </div>
          ))}
        </div>
      </div>

      <div className="p-4">
        <h1 className="text-xl font-semibold text-gray-100 mb-3">Overview</h1>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">

          <div className="bg-white/10 backdrop-blur-xl border border-white/20 p-5 rounded-2xl text-white text-center">
            <p className="text-lg font-medium">Humidity</p>
            <div className="text-5xl my-2">💧</div>
            <p className="text-2xl font-bold">67%</p>
            <p className="text-xs opacity-70 mt-1">Amount of moisture in the air</p>
          </div>

          <div className="bg-white/10 backdrop-blur-xl border border-white/20 p-5 rounded-2xl text-white text-center">
            <p className="text-lg font-medium">UV Index</p>
            <div className="w-4 h-24 mx-auto rounded-full bg-gradient-to-b from-yellow-300 via-orange-400 to-red-600 my-3"></div>
            <p className="text-sm font-medium">4 (Moderate)</p>
          </div>

          <div className="bg-white/10 backdrop-blur-xl border border-white/20 p-5 rounded-2xl text-white text-center">
            <p className="text-lg font-medium">Visibility</p>
            <div className="text-5xl my-2">🌫️</div>
            <p className="text-2xl font-bold">67%</p>
            <p className="text-xs opacity-70 mt-1">Haze is affecting visibility</p>
          </div>

        </div>
      </div>
    </>
  );
}

export default Home;
